# TCC
# atualização front end
https://github.com/Brondani-7/TCC/issues/1        
https://github.com/Brondani-7/TCC/pull/6
<img width="928" height="576" alt="Captura de tela 2025-09-03 230846" src="https://github.com/user-attachments/assets/c5f94858-c06e-437d-8de4-bdeabcec4221" />
<img width="902" height="558" alt="Captura de tela 2025-09-03 230833" src="https://github.com/user-attachments/assets/69391743-c34c-4391-93bc-9e5b0c4e2ae2" />
<img width="900" height="572" alt="Captura de tela 2025-09-03 230859" src="https://github.com/user-attachments/assets/7e692437-c376-4bf9-b6e8-2e7e8a0a796b" />
<img width="653" height="565" alt="Captura de tela 2025-09-03 230914" src="https://github.com/user-attachments/assets/ef3af4d2-ee13-4642-b095-8af9eca04fc2" />
# dificuldades em colocar links do youtube
# menu "head" com defeito foi corrigido apos duas mudanças leves no code
